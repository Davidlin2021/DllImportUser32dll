﻿namespace DllImportUser32dll
{
    partial class MainForm
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.FindWindows = new System.Windows.Forms.Button();
            this.bt_SendMessage = new System.Windows.Forms.Button();
            this.txtb_whandle = new System.Windows.Forms.TextBox();
            this.lb_WHandle = new System.Windows.Forms.Label();
            this.lb_CHandle = new System.Windows.Forms.Label();
            this.txtb_chandle = new System.Windows.Forms.TextBox();
            this.ShowWindows = new System.Windows.Forms.Button();
            this.HideWindows = new System.Windows.Forms.Button();
            this.lb_Message = new System.Windows.Forms.Label();
            this.ControlApp = new System.Windows.Forms.Button();
            this.BlockInput_MK = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // FindWindows
            // 
            this.FindWindows.Location = new System.Drawing.Point(11, 35);
            this.FindWindows.Name = "FindWindows";
            this.FindWindows.Size = new System.Drawing.Size(101, 23);
            this.FindWindows.TabIndex = 0;
            this.FindWindows.Text = "FindWindows";
            this.FindWindows.UseVisualStyleBackColor = true;
            this.FindWindows.Click += new System.EventHandler(this.FindWindows_Click);
            // 
            // bt_SendMessage
            // 
            this.bt_SendMessage.Location = new System.Drawing.Point(11, 122);
            this.bt_SendMessage.Name = "bt_SendMessage";
            this.bt_SendMessage.Size = new System.Drawing.Size(101, 23);
            this.bt_SendMessage.TabIndex = 1;
            this.bt_SendMessage.Text = "SendMessage";
            this.bt_SendMessage.UseVisualStyleBackColor = true;
            this.bt_SendMessage.Click += new System.EventHandler(this.SendMessage_Click);
            // 
            // txtb_whandle
            // 
            this.txtb_whandle.Location = new System.Drawing.Point(214, 34);
            this.txtb_whandle.Name = "txtb_whandle";
            this.txtb_whandle.Size = new System.Drawing.Size(69, 22);
            this.txtb_whandle.TabIndex = 2;
            // 
            // lb_WHandle
            // 
            this.lb_WHandle.AutoSize = true;
            this.lb_WHandle.Location = new System.Drawing.Point(121, 39);
            this.lb_WHandle.Name = "lb_WHandle";
            this.lb_WHandle.Size = new System.Drawing.Size(88, 12);
            this.lb_WHandle.TabIndex = 3;
            this.lb_WHandle.Text = "Windows Handle:";
            // 
            // lb_CHandle
            // 
            this.lb_CHandle.AutoSize = true;
            this.lb_CHandle.Location = new System.Drawing.Point(292, 39);
            this.lb_CHandle.Name = "lb_CHandle";
            this.lb_CHandle.Size = new System.Drawing.Size(68, 12);
            this.lb_CHandle.TabIndex = 5;
            this.lb_CHandle.Text = "Class Handle:";
            // 
            // txtb_chandle
            // 
            this.txtb_chandle.Location = new System.Drawing.Point(366, 34);
            this.txtb_chandle.Name = "txtb_chandle";
            this.txtb_chandle.Size = new System.Drawing.Size(69, 22);
            this.txtb_chandle.TabIndex = 4;
            // 
            // ShowWindows
            // 
            this.ShowWindows.Location = new System.Drawing.Point(11, 93);
            this.ShowWindows.Name = "ShowWindows";
            this.ShowWindows.Size = new System.Drawing.Size(101, 23);
            this.ShowWindows.TabIndex = 6;
            this.ShowWindows.Text = "ShowWindows";
            this.ShowWindows.UseVisualStyleBackColor = true;
            this.ShowWindows.Click += new System.EventHandler(this.ShowWindows_Click);
            // 
            // HideWindows
            // 
            this.HideWindows.Location = new System.Drawing.Point(11, 64);
            this.HideWindows.Name = "HideWindows";
            this.HideWindows.Size = new System.Drawing.Size(101, 23);
            this.HideWindows.TabIndex = 7;
            this.HideWindows.Text = "HideWindows";
            this.HideWindows.UseVisualStyleBackColor = true;
            this.HideWindows.Click += new System.EventHandler(this.HideWindows_Click);
            // 
            // lb_Message
            // 
            this.lb_Message.AutoSize = true;
            this.lb_Message.Location = new System.Drawing.Point(12, 9);
            this.lb_Message.Name = "lb_Message";
            this.lb_Message.Size = new System.Drawing.Size(47, 12);
            this.lb_Message.TabIndex = 8;
            this.lb_Message.Text = "Message:";
            // 
            // ControlApp
            // 
            this.ControlApp.Location = new System.Drawing.Point(11, 151);
            this.ControlApp.Name = "ControlApp";
            this.ControlApp.Size = new System.Drawing.Size(100, 23);
            this.ControlApp.TabIndex = 9;
            this.ControlApp.Text = "ControlApp";
            this.ControlApp.UseVisualStyleBackColor = true;
            this.ControlApp.Click += new System.EventHandler(this.ControlApp_Click);
            // 
            // BlockInput_MK
            // 
            this.BlockInput_MK.Location = new System.Drawing.Point(11, 180);
            this.BlockInput_MK.Name = "BlockInput_MK";
            this.BlockInput_MK.Size = new System.Drawing.Size(100, 23);
            this.BlockInput_MK.TabIndex = 10;
            this.BlockInput_MK.Text = "BlockInput";
            this.BlockInput_MK.UseVisualStyleBackColor = true;
            this.BlockInput_MK.Click += new System.EventHandler(this.BlockInput_MK_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(438, 206);
            this.Controls.Add(this.BlockInput_MK);
            this.Controls.Add(this.ControlApp);
            this.Controls.Add(this.lb_Message);
            this.Controls.Add(this.HideWindows);
            this.Controls.Add(this.ShowWindows);
            this.Controls.Add(this.lb_CHandle);
            this.Controls.Add(this.txtb_chandle);
            this.Controls.Add(this.lb_WHandle);
            this.Controls.Add(this.txtb_whandle);
            this.Controls.Add(this.bt_SendMessage);
            this.Controls.Add(this.FindWindows);
            this.Name = "MainForm";
            this.Text = "MainForm";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.Button FindWindows;
        public System.Windows.Forms.Button bt_SendMessage;
        private System.Windows.Forms.TextBox txtb_whandle;
        private System.Windows.Forms.Label lb_WHandle;
        private System.Windows.Forms.Label lb_CHandle;
        private System.Windows.Forms.TextBox txtb_chandle;
        private System.Windows.Forms.Button ShowWindows;
        private System.Windows.Forms.Button HideWindows;
        private System.Windows.Forms.Label lb_Message;
        private System.Windows.Forms.Button ControlApp;
        private System.Windows.Forms.Button BlockInput_MK;
    }
}

