﻿using System;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace DllImportUser32dll
{
    public partial class MainForm : Form
    {
        [DllImport("User32.dll", EntryPoint = "FindWindow")]
        public static extern IntPtr FindWindow(string lpClassName, string lpWindowName);
                
        [DllImport("User32.dll", EntryPoint = "FindWindowEx")]        
        public static extern IntPtr FindWindowEx(IntPtr hwndParent, IntPtr hwndChildAfter, string lpClassName, string lpWindowName);

        [DllImport("User32.dll", SetLastError = true)]
        static extern int SendMessage(IntPtr hWnd, int msg, int wParam, StringBuilder lParam);

        [DllImport("User32.dll", EntryPoint = "ShowWindow", CharSet = CharSet.Auto)]
        public static extern int ShowWindow(IntPtr hwnd, int nCmdShow);

        [DllImport("User32.dll")]
        private static extern bool SetWindowPos(IntPtr hWnd, IntPtr hWndInsertAfter, int X, int Y, int cx, int cy, uint uFlags);
       
        public partial class NativeMethods
        {
            [DllImport("user32.dll", EntryPoint = "BlockInput")]
            [return: MarshalAs(UnmanagedType.Bool)]
            internal static extern bool BlockInput([MarshalAs(UnmanagedType.Bool)] bool fBlockIt);
        }

        #region SetWindowPos 參數
        public const int HWND_TOP = 0;
        public const int HWND_BOTTOM = 1;
        public const int HWND_TOPMOST = (-1);
        public const int HWND_NOTOPMOST = (-2);
        public const int SWP_NOSIZE = 1;
        public const int SWP_NOMOVE = 2;
        #endregion
        #region ShowWindow 參數
        /// 隐藏窗口并激活其他窗口
        public const int SW_HIDE = 0;

        /// 激活并显示一个窗口。如果窗口被最小化或最大化，系统将其恢复到原来的尺寸和大小。应用程序在第一次显示窗口的时候应该指定此标志
        public const int SW_SHOWNORMAL = 1;

        /// 激活窗口并将其最小化
        public const int SW_SHOWMINIMIZED = 2;

        /// 激活窗口并将其最大化
        public const int SW_SHOWMAXIMIZED = 3;

        /// 以窗口最近一次的大小和状态显示窗口。此值与SW_SHOWNORMAL相似，只是窗口没有被激活
        public const int SW_SHOWNOACTIVATE = 4;

        /// 在窗口原来的位置以原来的尺寸激活和显示窗口
        public const int SW_SHOW = 5;

        /// 最小化指定的窗口并且激活在Z序中的下一个顶层窗口
        public const int SW_MINIMIZE = 6;

        /// 最小化的方式显示窗口，此值与SW_SHOWMINIMIZED相似，只是窗口没有被激活
        public const int SW_SHOWMINNOACTIVE = 7;

        /// 以窗口原来的状态显示窗口。此值与SW_SHOW相似，只是窗口没有被激活
        public const int SW_SHOWNA = 8;

        /// 激活并显示窗口。如果窗口最小化或最大化，则系统将窗口恢复到原来的尺寸和位置。在恢复最小化窗口时，应用程序应该指定这个标志
        public const int SW_RESTORE = 9;

        /// 依据在STARTUPINFO结构中指定的SW_FLAG标志设定显示状态，STARTUPINFO 结构是由启动应用程序的程序传递给CreateProcess函数的
        public const int SW_SHOWDEFAULT = 10;

        /// 最小化窗口，即使拥有窗口的线程被挂起也会最小化。在从其他线程最小化窗口时才使用这个参数
        public const int SW_FORCEMINIMIZE = 11;
        #endregion

        #region SendMessage 參數
        public const int WM_SETTEXT = 0x000C;
        #endregion

        #region FindWindow/FindWindowEx 參數
        public IntPtr hwnd;
        public IntPtr hwndex;
        public IntPtr hWndButton;
        #endregion

        public MainForm()
        {
            InitializeComponent();
        }
        private void FindWindows_Click(object sender, EventArgs e)
        {
            //App主視窗
            hwnd = FindWindow(null, "Wireless Network Watcher");
            txtb_whandle.Text = hwnd.ToString();

            //App Toolbar
            hwndex = FindWindowEx(hwnd, IntPtr.Zero, "ToolbarWindow32", null);
            txtb_chandle.Text = hwndex.ToString();

            //App主視窗 & App Toolbar是否抓到
            if ((hwnd != IntPtr.Zero) && (hwndex != IntPtr.Zero))
               {
                  lb_Message.Text= "Message:Wireless Network Watcher hwnd & hwndex found!!";
               }
            else
               {
                  lb_Message.Text = "Message:No Wireless Network Watcher found!!";
               }
        }
        private void HideWindows_Click(object sender, EventArgs e)
        {
            //No Handle跳離
            if (txtb_whandle.Text == "")
            {
                MessageBox.Show("No Handle found!!");
                return;
            }
            ShowWindow(hwnd, SW_HIDE);
            lb_Message.Text = "Message:Hide Wireless Network Watcher Windows!!";
        }
        private void ShowWindows_Click(object sender, EventArgs e)
        {
            //No Handle跳離
            if (txtb_whandle.Text == "")
            {
                MessageBox.Show("No Handle found!!");
                return;
            }
            ShowWindow(hwnd, SW_SHOWNORMAL);
            lb_Message.Text = "Message:Show Wireless Network Watcher Windows!!";
        }
        private void ControlApp_Click(object sender, EventArgs e)
        {
            //App 至頂顯示
            SetWindowPos(hwnd, (IntPtr)HWND_TOPMOST, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE);
            
            //控制App傳快捷鍵F5執行Start Scanning
            System.Threading.Thread.Sleep(800);
            SendKeys.Send("{F5}");
            System.Threading.Thread.Sleep(500);
            lb_Message.Text = "Message:Start Scanning => Wireless Network Watcher App!!";
        }
        private void SendMessage_Click(object sender, EventArgs e)
        {
            //No Handle跳離
            if (txtb_chandle.Text == "")
            {
                MessageBox.Show("No Handle found!!");
                return;
            }
            //修改ToolbarWindow32標題為ToolbarWindow32
            StringBuilder InsStr = new StringBuilder();
            InsStr.Append("ToolbarWindow32");
            SendMessage(hwndex, WM_SETTEXT, 0, InsStr);
            lb_Message.Text = "Message:Add ToolbarWindow32 title!!";
        }
        
        private void BlockInput_MK_Click(object sender, EventArgs e)
        {
            NativeMethods.BlockInput(true);
            lb_Message.Text = "Message:BlockInput KeyBoard and Mouse";
        }
    }
}
